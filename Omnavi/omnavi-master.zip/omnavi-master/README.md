# omnavi
Un website usado como proyecto personal y escolar, una página que tiene un objetivo de entretenimiento e informativa. Mi primer proyecto, el punto de partida.
